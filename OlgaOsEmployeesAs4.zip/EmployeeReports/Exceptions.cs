﻿using System;

namespace Employees
{
	public class Exceptions
	{
		//An Exceptions class contains application-specific exceptions.
		public Exceptions ()
		{
		}
		//Custom TooManyReportsException exception extends ApplicationException and represents the error message
		//if a manager get more than a maximum number of reports

		public class TooManyReportsException : ApplicationException
		{
			public TooManyReportsException ()
			{
			}

			public TooManyReportsException (string message) : base (message)
			{
			}
		}
	}
}
