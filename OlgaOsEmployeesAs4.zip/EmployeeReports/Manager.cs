﻿using System;
using System.Collections;

namespace Employees
{
	// Managers need to know their number of stock options and reports
	public class Manager : Employee, IEnumerable
	{
		#region constructors

		public Manager ()
		{
		}

		public Manager (string fullName, int age, int empID,
		                float currPay, string ssn, int numbOfOpts)
			: base (fullName, age, empID, currPay, ssn)
		{
			// This property is defined by the Manager class.
			StockOptions = numbOfOpts;
		}

		#endregion

		#region Constants, data members and properties

		// Use a private member for reports - initially all a null Employee (Manager)
		public const int MaxReports = 5;
		private static readonly Employee NullEmp = new Manager ();
		private Employee[] _reports = { NullEmp, NullEmp, NullEmp, NullEmp, NullEmp };

		// StockOptions are unique to Managers
		public int StockOptions { get; set; }

		#endregion


		#region three named IEnumerators

		public IEnumerator GetEnumerator ()
		{
			// Return the array object's IEnumerator.
			return _reports.GetEnumerator ();
		}



		public IEnumerable ReportsByName ()
		{
			Employee[] _reportsSorted = new Employee[_reports.Length];
			NameComparer comparer = new NameComparer ();
			int pos = 0;
			//Copying data from array '_reports' to array '_reportsSorted 
			for (int i = 0; i < _reports.Length; i++) {
				if (_reports [i] != NullEmp) {
					_reportsSorted [pos] = _reports [i];
					pos++;
				}
			}
			//Changes the number of elements of a one-dimensional array to the specified new size.
			Array.Resize (ref _reportsSorted, pos);
			//sort new array
			Array.Sort (_reportsSorted, comparer);
			return _reportsSorted;
		}

		public IEnumerable ReportsByAge ()
		{
			Employee[] _reportsSorted = new Employee[_reports.Length];
			AgeComparer comparer = new AgeComparer ();

			int pos = 0;
			//Copying data from array '_reports' to array '_reportsSorted 
			for (int i = 0; i < _reports.Length; i++) {
				if (_reports [i] != NullEmp) {
					_reportsSorted [pos] = _reports [i];
					pos++;
				}
			}
			//Changes the number of elements of a one-dimensional array to the specified new size.
			Array.Resize (ref _reportsSorted, pos);
			//sort new array
			Array.Sort (_reportsSorted, comparer);
			return _reportsSorted;
		}

		public IEnumerable ReportsByPay ()
		{        
			Employee[] _reportsSorted = new Employee[_reports.Length];
			PayComparer comparer = new PayComparer ();

			int pos = 0;
			//Copying data from array '_reports' to array '_reportsSorted 
			for (int i = 0; i < _reports.Length; i++) {
				if (_reports [i] != NullEmp) {
					_reportsSorted [pos] = _reports [i];
					pos++;
				}
			}
			//Changes the number of elements of a one-dimensional array to the specified new size.
			Array.Resize (ref _reportsSorted, pos);
			//sort new array
			Array.Sort (_reportsSorted, comparer);
			return _reportsSorted;
		}

		#endregion

		#region Class Methods

		// Override GiveBonus to change stock options for Manager
		public override void GiveBonus (float amount)
		{
			base.GiveBonus (amount);
			Random r = new Random ();
			StockOptions += r.Next (500);
		}
			


		public virtual void AddReport (Employee emp)
		{
			string reports = ReportLine ();

			//create exception
			Exceptions.TooManyReportsException ex =
				new Exceptions.TooManyReportsException (string.Format ("Manager already has 5 reports.")); 
			
			int emptyPos = Array.IndexOf (_reports, NullEmp);

			// Array full - no empty positions
			if (emptyPos < 0) {
				
				//The exception has three data values to the exception:
				//the manager name, the names of the reports one line separated by a space,
				//and the name of the employee that did not get added as a report.

				ex.Data.Add ("Manager", this.Name);
				ex.Data.Add ("Reports", reports);
				ex.Data.Add ("New Report", emp.Name);
				throw ex;
			}

            // Only add report if not already a report
            else if (Array.IndexOf (_reports, emp) < 0) {
				// Put Employee in empty position
				_reports.SetValue (emp, emptyPos);
			}
		}

		// Replace report with null employee (if found)
		public virtual void RemoveReport (Employee emp)
		{
			// See if the passed employee is a report
			int pos = Array.IndexOf (_reports, emp);

			if (pos >= 0) {
				_reports.SetValue (NullEmp, pos);
			}
		}

		// Display Manager with stock options and list of reports
		public override void DisplayStats ()
		{
			base.DisplayStats ();
			Console.WriteLine ("Stock Options: {0:N0}", StockOptions);

			// Print out reports on a single line
			Console.Write ("Reports: ");
			foreach (Employee report in this) {
				if (report != NullEmp)
					Console.Write ("{0} ", report.GetName ());
			}
			Console.WriteLine ();
		}
			
		//The ReportLine method returns the names of the reports one line separated by a space
		private string ReportLine ()
		{
			string name = "";
			foreach (Employee report in _reports) {
				if (report != NullEmp)
					name += report.GetName () + " ";
			}
			return name;
		}

		#endregion
	}
}