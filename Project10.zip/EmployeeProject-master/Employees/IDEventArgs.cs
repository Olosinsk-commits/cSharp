﻿using System;

namespace Employees
{
	public class IDEventArgs: EventArgs
	{

		public readonly int id;
		public readonly string ids;

		public IDEventArgs (string ids1)
		{
			ids=ids1;
		}
	}
}

