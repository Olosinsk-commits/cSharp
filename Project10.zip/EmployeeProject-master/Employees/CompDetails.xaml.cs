﻿using System.Windows.Controls;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using System.Collections.Specialized;
using System.Linq;

namespace Employees
{
    [System.Serializable]
    public partial class CompDetails : Page
    {
        Employee empl;


        private EmployeeList emplL;


        //private float amount;
        #region Constructors
        Manager mngR;

        public CompDetails()
        {
            InitializeComponent();
            //empList = null;

        }

        // Custom constructor to pass Employee object
        public CompDetails(object data, EmployeeList emplLT) : this()
        {
            // Bind context to Employee
            this.DataContext = data;
            emplL = emplLT;
            BonusNumber.DataContext = this;

            if (data is Employee)
            {
                Employee emp = (Employee)data;

                empl = emp;
                string name1 = "";
                string value1 = "";
                string name2 = "";
                string value2 = "";

                emp.SpareDetailProp1(ref name1, ref value1);
                SpareProp1Name.Content = name1;
                SpareProp1Value.Content = value1;


                if (data is Manager)
                {
                    SpareProp2Combo.Visibility = Visibility.Visible;
                    SpareProp2Value.Visibility = Visibility.Visible;
                    SpareProp2Value.Visibility = Visibility.Visible;
                    SpareProp2Name.Visibility = Visibility.Visible;
                    RemoveButton.Visibility = Visibility.Visible;
                    RBt.Visibility = Visibility.Visible;

                    emp.SpareDetailProp2(ref name2, ref value2);
                    SpareProp2Name.Content = name2;

                    Manager mng = (Manager)data;
                    mngR = mng;
                    var reports = mngR.IsValidReport(true);
                    SpareProp2Value.ItemsSource = reports;


                    var whohasreports = (List<Employee>)emplL.FindAll(obj => (obj is Manager));

                    // List<Employee> emplList1;
                    List<Employee> emplList = emplL;
                    //EmployeeList tempList;
                    foreach (Manager mngrt in whohasreports)
                    {
                        var EmployeeListR = mngrt.GetReports();
                        List<Employee> theyhasreports;
                        theyhasreports = emplList.Except(EmployeeListR).Distinct().ToList();
                        emplList = theyhasreports;
                    }
                    if (data is Executive)
                    {
                        List<Employee> emplList1 = (List<Employee>)emplList.FindAll(obj => !(obj is Engineer || obj is SupportPerson) && obj != emp);
                        SpareProp2Combo.ItemsSource = emplList1;
                    }
                    else
                    {
                        List<Employee> emplList1 = (List<Employee>)emplList.FindAll(obj => !(obj is Executive) && obj != emp);
                        SpareProp2Combo.ItemsSource = emplList1;
                    }


                }
            }
        }
        #endregion

        public float BonusTemp
        {
            get; set;
        } = 500;


        // Handle give promotion button click
        private void GivePromotion_Click(object sender, RoutedEventArgs e)
        {
            empl.GivePromotion();
            object obj = DataContext;
            DataContext = null;
            DataContext = obj;
        }

        private void Refresh_Bonus()
        {
            object obj = DataContext;
            DataContext = null;
            DataContext = obj;
        }
        private void Bonus_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            if (BonusTemp >= 500 && BonusTemp <= 10000)
            {
                e.CanExecute = true;
            }
            else
                e.CanExecute = false;

        }

        private void Bonus_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            empl.GiveBonus(BonusTemp);
            this.Refresh_Bonus();
        }


        public void Refresh()
        {
            this.NavigationService.Navigate(new CompDetails(empl, emplL));
        }

        // Handle enable/disable of Details and Expenses buttons
        private void Button_CanExecuteAReport(object sender, CanExecuteRoutedEventArgs e)
        {
            // Check if an Employee is selected to enable Review button
            e.CanExecute = SpareProp2Combo.SelectedIndex >= 0;
        }

        private void Button_CanExecuteRReport(object sender, CanExecuteRoutedEventArgs e)
        {
            // Check if an Employee is selected to enable Review button
            e.CanExecute = SpareProp2Value.SelectedIndex >= 0;
        }


        // Handle RemoveReport_Executed button click
        private void RemoveReport_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            this.NavigationService.Navigate(new CompDetails(empl, emplL));
        }

        // Handle ReportAdd_Executed button click
        private void ReportAdd_Executed(object sender, ExecutedRoutedEventArgs e)
        {


            this.NavigationService.Navigate(new CompDetails(empl, emplL));
        }


        private void RemoveR_Click(object sender, RoutedEventArgs e)
        {
            Employee rprt = (Employee)SpareProp2Value.SelectedItem;
            mngR.RemoveReport(rprt);

        }

        private void Add_Report_Click(object sender, RoutedEventArgs e)

        {
            Employee rprtA = (Employee)SpareProp2Combo.SelectedItem;
            mngR.AddReport(rprtA);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}

