﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{

	//The BenefitPackage class returns Benefit Package Level and Computes Pay Deduction
	public class BenefitPackage
	{
		public BenefitPackageLevel level;

		// A custom enumeration for Benefit Package Level
		public enum BenefitPackageLevel
		{
			Standard,
			Gold,
			Platinum
		}


		public BenefitPackage ()
			: this (BenefitPackageLevel.Standard)
		{
		}

		public BenefitPackage (BenefitPackageLevel bpLevel)
		{
			this.level = bpLevel; 
		}


		public BenefitPackageLevel GetPackageLevel ()
		{
			return level;
		}

		//ComputePayDeduction depends on Benefit Package Level and costs 125.00,
		//150.00, and 200.00 for Standard, Gold, and Platinum, respectively

		public double ComputePayDeduction ()
		{
			if (level == BenefitPackageLevel.Standard)
				return 125.0;
			else if (level == BenefitPackageLevel.Gold)
				return 150.0;
			else
				return 200.0;
		}
	}
		
}
