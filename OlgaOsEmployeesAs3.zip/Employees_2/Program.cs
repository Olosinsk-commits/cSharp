﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
	class Program
	{
		static void Main (string[] args)
		{
			Console.WriteLine ("***** Assignment 3: Employee class hierarchy *****\n");

			// Create Employees
			Manager chucky = new Manager ("Chucky", 50, 92, 100000, "333-23-2322", 9000);
			SalesPerson fran = new SalesPerson ("Fran", 43, 93, 3000, "932-32-3232", 31);
			Engineer bob = new Engineer ("Bob", 31, 94, 120000, "334-24-2422", Engineer.EngineerDegree.MS);
			SupportPerson sally = new SupportPerson ("Sally", 32, 95, 80000, "913-43-4343", SupportPerson.Shift.Afternoon);

			// Give bonuses and promotions
			bob.GiveBonus (500);
			sally.GiveBonus (400);
			chucky.GivePromotion ();
			fran.GivePromotion ();

			// Extra Credit - uncomment appropriate section

			//Reports extra credit
			chucky.RemoveReport (bob);
			chucky.AddReport (bob);
			chucky.AddReport (sally);
			chucky.AddReport (bob);
			chucky.RemoveReport (bob);
			chucky.RemoveReport (chucky);
           

			//Executive extra credit
			Executive mike = new Executive ("Mike", 54, 90, 200000, "121-12-1211", 50000, Executive.ExecTitle.CEO);
			Executive mary = new Executive ("Mary", 45, 91, 150000, "229-67-7898", 40000, Executive.ExecTitle.CFO);
			mike.GivePromotion ();
			mary.GiveBonus (1000);
			mike.AddReport (chucky);
			mary.AddReport (fran);
			mary.AddReport (sally);


			// List employees - use seccond line for Executive extra credit
			//Employee[] emps = { chucky, fran, bob, sally };
			Employee[] emps = { mike, mary, chucky, fran, bob, sally };

			// Display employees
			Console.WriteLine ("\nEmployee RollCall:\n");
			foreach (Employee emp in emps) {
				emp.DisplayStats ();
				Console.WriteLine ();
			}

			Console.ReadLine ();
		}



	}
}
