﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Engineers include a Degree property that takes one of the values from (BS, MS, PhD)

namespace Employees
{
	class Engineer: Employee
	{
		// A custom enumeration for Engineer's degree
		public enum EngineerDegree
		{
			BS,
			MS,
			PhD
		}

		#region constructors

		//default constructor
		public Engineer ()
		{
			Degree = EngineerDegree.BS;
		}

		public EngineerDegree Degree { get; set; }

		//this constructor provides Benefit PackageLevel Standard by default if we do not
		//provide Benefit Package Level in the time of creating an instance of that class

		public Engineer (string fullName, int age, int empID,
		                 float currPay, string ssn, EngineerDegree degreeE)
			: base (fullName, age, empID, currPay, ssn, BenefitPackage.BenefitPackageLevel.Standard)
		{
			// This property is defined by the Engineer class.
			Degree = degreeE;
		}

		//The custom Engineer constructor allows to establish a degree (via a custom enum named EngineerDegree).
		public Engineer (string fullName, int age, int empID,
		                 float currPay, string ssn, BenefitPackage.BenefitPackageLevel empbenefit, EngineerDegree degreeE)
			: base (fullName, age, empID, currPay, ssn, empbenefit)
		{
			// This property is defined by the Engineer class.
			Degree = degreeE;
		}

		#endregion

		/*
		 * A Engineer class changes the implementation detail and overrides the virtual method GiveBonus().
		 * This method has been declared virtually in the Employee class.
		 * A Engineer's bonus is influenced by their degree.
		*/
		public override void GiveBonus (float amount)
		{
			
			base.GiveBonus (amount);
		}

		public override float GiveExtra ()
		{
			float extraAmount = base.GiveExtra () + 600;
			//float extraAmount=300;
			return extraAmount;
		}

		public override void GivePromotion (float amount)
		{
			Console.WriteLine ("< Engineer >");
			base.GivePromotion (amount);
			Console.WriteLine ();

		}

		public override void GivePromotion ()
		{
			Console.WriteLine ("< Engineer >");
			base.GivePromotion ();
			Console.WriteLine ();
		}

		/*
		 * A Engineer class changes the implementation detail and overrides the virtual method DisplayStats().
		 * This method has been declared virtually in the Employee class.
		 */

		public override void DisplayStats ()
		{
			base.DisplayStats ();
			Console.WriteLine ("Degree is: {0}", Degree);
			Console.WriteLine ();
		}


	}
}

