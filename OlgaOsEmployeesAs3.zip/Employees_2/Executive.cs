﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
	class Executive : Manager
	{
		List<Employee> reports = new List<Employee> ();

		public enum ExecTitle
		{
			CEO,
			CTO,
			CFO,
			VP
		}
		/*
		 * The AddReport method adds a report to a manager and 
		 * returns a bool indicating success/failure on adding report. This method prints
		 * an error to the console when employee already present or too many reports
		 * An Executive report can be a Manager, a SalesPerson, or another Executive, but not a SupportPerson or Engineer
		 * An Executive class changes the implementation detail and overrides the virtual method AddReport() from Manager class.
		 */

		public override bool AddReport (Employee empl)
		{
			//Console.WriteLine ("Adding to the {0} report list. Employee: {1}!", Name, empl.Name);

			if (empl is SupportPerson) {
				Console.WriteLine ("Error! Employee {0} is a Support Person and can't be added to {1}'s report list!", empl.Name, Name);
				Console.WriteLine ("An Executive report must be a Manager, a SalesPerson, or another Executive!");
				Console.WriteLine ();
				return false;
			}
			if (empl is Engineer) {
				Console.WriteLine ("Error! Employee {0} is an Engineer and can't be added to {1}'s report list!", empl.Name, Name);
				Console.WriteLine ("An Executive report must be a Manager, a SalesPerson, or another Executive!");
				Console.WriteLine ();
				return false;
			}
				
			return base.AddReport (empl);
		}


		//An Executive class changes the implementation detail and overrides the virtual method RemoveReport().

		public override bool RemoveReport (Employee empl)
		{
			return base.RemoveReport (empl);
		}


		public ExecTitle ETitle { get ; set ; }

		/*
		 * Constructors. 
		 * An Executive starts with 10,000 stock options on hire - i.e., object construction - unless otherwise specified
		 * An Executive starts at the Gold Benefit Package Level on hire
		 * An Executive gets an extra 1000 bonus and 10,000 stock options on promotion
        */

		public Executive ()
		{
			ETitle = ExecTitle.VP;
		}


		public Executive (string fullName, int age, int empID,
		                  float currPay, string ssn, int numbOfOpts, ExecTitle title)
			: base (fullName, age, empID, currPay, ssn, BenefitPackage.BenefitPackageLevel.Gold, numbOfOpts)
		{
			ETitle = title;
	
		}

		public Executive (string fullName, int age, int empID,
		                  float currPay, string ssn, ExecTitle title)
			: base (fullName, age, empID, currPay, ssn, BenefitPackage.BenefitPackageLevel.Gold, 10000)
		{
			ETitle = title;
		}

		//The GiveBonus method
		public override void GiveBonus (float amount)
		{
			base.GiveBonus (amount);
		}


		public override float GiveExtra ()
		{
			//float extraAmount = 400 (+600 from base class);
			float extraAmount = base.GiveExtra () + 400;
			//float extraAmount=300;
			StockOptions = StockOptions + 10000; 
			return extraAmount;

		}

		public override void GivePromotion (float amount)
		{
			Console.WriteLine ("< Executive >");

			//Print out promotion message to the console at promotion time
			base.GivePromotion (amount); 
			//Console.WriteLine ("New StockOptions is: {0}", StockOptions);
			Console.WriteLine ();

		}

		public override void GivePromotion ()
		{
			Console.WriteLine ("< Executive >");
			base.GivePromotion (); 
			//Console.WriteLine ("ExecTitle StockOptions {0}", StockOptions);
			Console.WriteLine ();
		}
		/*
		 * A Executive class changes the implementation detail and overrides the virtual method DisplayStats().
		 */
		public override void DisplayStats ()
		{
			base.DisplayStats ();
		}
	}
}
