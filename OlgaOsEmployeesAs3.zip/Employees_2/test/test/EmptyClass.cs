﻿using System;

namespace test
{
	public class EmptyClass
	{
		public EmptyClass ()
		{
		}
	}
}

