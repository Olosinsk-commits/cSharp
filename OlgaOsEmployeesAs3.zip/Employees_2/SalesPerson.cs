﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
	// Salespeople need to know their number of sales.
	class SalesPerson : Employee
	{
		#region constructors

		public SalesPerson ()
		{
		}


		public SalesPerson (string fullName, int age, int empID,
		                   float currPay, string ssn, int numbOfSales)
			: base (fullName, age, empID, currPay, ssn, BenefitPackage.BenefitPackageLevel.Standard)
		{
			// This belongs with us!
			SalesNumber = numbOfSales;
		}

		// As a general rule, all subclasses should explicitly call an appropriate
		// base class constructor.


		public SalesPerson (string fullName, int age, int empID,
		                         float currPay, string ssn, BenefitPackage.BenefitPackageLevel empbenefit, int numbOfSales)
			: base (fullName, age, empID, currPay, ssn, empbenefit)
		{
			// This belongs with us!
			SalesNumber = numbOfSales;
		}

		#endregion

		public int SalesNumber { get; set; }

		// A salesperson's bonus is influenced by the number of sales.
		public override sealed void GiveBonus (float amount)
		{ 
			base.GiveBonus (amount);
		}

		public override float GiveExtra ()
		{
			float extraAmount = base.GiveExtra () + 300;
			//float extraAmount=300;
			return extraAmount;
		}

		public override void GivePromotion (float amount)
		{
			Console.WriteLine ("< SalesPerson >");
			base.GivePromotion (amount);
			Console.WriteLine ();

		}

		public override void GivePromotion ()
		{
			Console.WriteLine ("< SalesPerson >");
			base.GivePromotion ();
			Console.WriteLine ();
		}


		public override void DisplayStats ()
		{
			base.DisplayStats ();
			Console.WriteLine ("Number of sales: {0}", SalesNumber);
			Console.WriteLine ();
		}
	}
}
