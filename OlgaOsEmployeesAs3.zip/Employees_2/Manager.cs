﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
	// Managers need to know their number of stock options.
	class Manager : Employee
	{
		#region constructors

		static int maxNumberOfreports = 10; //A manager has a maximum of 10 reports

		List<Employee> reports = new List<Employee> ();//reports field that indicates which Employees report to a manager

		/*
		 * The AddReport method adds a report to a manager and 
		 * returns a bool indicating success/failure on adding report. This method prints
		 * an error to the console when employee already present or too many reports
		*/

		public virtual bool AddReport (Employee empl)
		{

			Console.WriteLine ("Adding to the {0}'s report list. Employee: {1}!", Name, empl.Name);
			//Gets the number of elements actually contained in the ArrayList.
			if (reports.Count () >= maxNumberOfreports) {
				Console.WriteLine ("Error! Too many reports!!!");
				Console.WriteLine ();
				return false;
			}	

			foreach (Employee emp in reports) {
				//ArrayList.Contains() method checks whether specified element exists in the ArrayList or not. Returns true if exists otherwise false.
				if (reports.Contains (empl) == true) {
					Console.WriteLine ("Error! This employee presents in the {0}'s report list!", Name);
					Console.WriteLine ();
					return false;
				} 	
			}
			foreach (Employee emp in reports) {
				//ArrayList.Contains() method checks whether specified element exists in the ArrayList or not. Returns true if exists otherwise false.
				if (empl.Name == Name) {
					Console.WriteLine ("Error! {0} can't report to themself!", Name);
					Console.WriteLine ();
					return false;
				} 
			}
			reports.Add (empl);
			Console.WriteLine ("Employee {0} was added to the {1}'s report list", empl.Name, Name);
			Console.WriteLine ();
			return true;
		}

		/*
		 * The RemoveReport method removes a report from a manager, returning a
		 * bool indicating success/failure and prints an error
		 * to the console when employee is not present
		*/
		public virtual bool RemoveReport (Employee empl)
		{
			Console.WriteLine ("Removing from the {0} report list. Employee: {1}!", Name, empl.Name);
			//Gets the number of elements actually contained in the ArrayList.
			if (reports.Count () == 0) {
				Console.WriteLine ("Error! Employee list is empty!");
				Console.WriteLine ();
				return false;
			}

			foreach (Employee emp in reports) {
				//ArrayList.Contains() method checks whether specified element exists in the ArrayList or not. Returns true if exists otherwise false.
				if (reports.Contains (empl) == false) {
					Console.WriteLine ("Error! This employee is not present in the {0}'s report list!", Name);
					Console.WriteLine ();
					return false;
				} 	
			}

			reports.Remove (empl);//Remove() method removes the specified element from the ArrayList. 
			Console.WriteLine ("Employee {0} was removed from {1}'s report list!", empl.Name, Name);
			Console.WriteLine ();
			return true;
		}

		//constructors
		public Manager ()
		{

		}

		public Manager (string fullName, int age, int empID,
		                float currPay, string ssn, int numbOfOpts)
			: base (fullName, age, empID, currPay, ssn, BenefitPackage.BenefitPackageLevel.Standard)
		{
			// This property is defined by the Manager class.
			StockOptions = numbOfOpts;
		}

		public Manager (string fullName, int age, int empID,
		                float currPay, string ssn, BenefitPackage.BenefitPackageLevel empbenefit, int numbOfOpts)
			: base (fullName, age, empID, currPay, ssn, empbenefit)
		{
			// This property is defined by the Manager class.
			StockOptions = numbOfOpts;
		}

		#endregion

		public int StockOptions { get; set; }

		//The GiveBonus method
		public override void GiveBonus (float amount)
		{
			base.GiveBonus (amount);
		}

		public override float GiveExtra ()
		{
			float extraAmount = base.GiveExtra () + 600;
			//float extraAmount=300;
			return extraAmount;
		}

		public override void GivePromotion (float amount)
		{
			Console.WriteLine ("< Manager >");
			base.GivePromotion (amount); 
			Console.WriteLine ();
		}

		public override void GivePromotion ()
		{
			base.GivePromotion ();
			Console.WriteLine ();
		}


		public override void DisplayStats ()
		{
			base.DisplayStats ();
			Console.WriteLine ("Number of Stock Options: {0}", StockOptions);

			//Display the Name of each report on a single line in the DisplayStats method
			Console.WriteLine ("Reports:\n");
			foreach (Employee emp in reports) {
				Console.WriteLine (emp.Name);
			}

		}
	}
}
