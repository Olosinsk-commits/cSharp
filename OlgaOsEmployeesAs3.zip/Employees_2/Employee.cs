﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
	abstract partial class Employee
	{
		#region Class methods

		//Moving the GivePromotion method to the Employee class
		//A promotion bumps the Benefit Package Level one level for all Employees when possible
		//(i.e., Standard to Gold or Gold to Platinum) - this is the only way the BenefitPackageLevel can change after object construction

		public virtual void GivePromotion ()
		{
			float baseBonus = 0;
			//Print out promotion message to the console at promotion time
			Console.WriteLine ("Give promotion.");
			Console.WriteLine ("Employee Name: {0}", Name);
			Console.WriteLine ("Current ====> Benefit Package Level: {0}. Bonus: {1}.", empBenefits.level, baseBonus);

			float extra = GiveExtra ();
			float fullBonus = extra + baseBonus;
			BumpLevel ();
			Console.WriteLine ("New     ====> Benefit Package Level: {0}. Final Bonus: {1}", empBenefits.level, fullBonus);
			Console.WriteLine ("---------------------------------------------------------------");
		}

		public virtual void GivePromotion (float amount)
		{			
			float extra = GiveExtra ();
			float fullBonus = amount + extra;
			//Print out promotion message to the console at promotion time
			Console.WriteLine ("Give promotion.");
			Console.WriteLine ("Employee Name: {0}", Name);
			Console.WriteLine ("Current ====> Benefit Package Level: {0}. Bonus: {1}.", empBenefits.level, amount);
			BumpLevel ();
			Console.WriteLine ("New     ====> Benefit Package Level: {0}. Final Bonus: {1}", empBenefits.level, fullBonus);
			Console.WriteLine ("---------------------------------------------------------------");

		}

		public virtual float GiveExtra ()
		{
			float extraAmount = 0;
			return extraAmount;
		}

		public virtual void GiveBonus (float amount)
		{
			
			Console.WriteLine ("Employee Name: {0}. Give bonus: {1}", Name, amount);
			Console.WriteLine ("---------------------------------------------------------------");
		}


		private void BumpLevel ()
		{
			BenefitPackage.BenefitPackageLevel currentBPpLevel;
			BenefitPackage.BenefitPackageLevel newBPpLevel;
			currentBPpLevel = Benefits.GetPackageLevel ();


			if (currentBPpLevel == BenefitPackage.BenefitPackageLevel.Standard)
				newBPpLevel = BenefitPackage.BenefitPackageLevel.Gold;
			else if (currentBPpLevel == BenefitPackage.BenefitPackageLevel.Gold)
				newBPpLevel = BenefitPackage.BenefitPackageLevel.Platinum;
			else
				newBPpLevel = BenefitPackage.BenefitPackageLevel.Platinum;
			
			empBenefits.level = newBPpLevel;
		}


		public virtual void DisplayStats ()
		{
			//creating a new local variable bplevel 
			BenefitPackage.BenefitPackageLevel bplevel;

			//the Benefits.GetPackage() returns the Benefit Package Level and assign it to local variable bp level
			bplevel = Benefits.GetPackageLevel ();

			Console.WriteLine ("Name: {0}", Name);
			Console.WriteLine ("ID: {0}", ID);
			Console.WriteLine ("Age: {0}", Age);
			Console.WriteLine ("Pay: {0}", Pay);
			Console.WriteLine ("SSN: {0}", SocialSecurityNumber);
			//Add Benefit Package Level to DisplayStats
			Console.WriteLine ("Benefit Package Level: {0}", bplevel);
		}

		#endregion

		#region Traditional Get / Set method

		// Accessor (get method)
		public string GetName ()
		{
			return empName;
		}

		// Mutator (set method)
		public void SetName (string name)
		{
			// Do a check on incoming value
			// before making assignment.
			if (name.Length > 15)
				Console.WriteLine ("Error!  Name must be less than 15 characters!");
			else
				empName = name;
		}

		#endregion
	}



}
