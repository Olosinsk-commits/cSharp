﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//The SupportPerson includes a Shift property to indicate which of the three time periods an employee works.

namespace Employees
{
	class SupportPerson: Employee
	{

		// A custom enumeration for Engineer's degree
		public enum Shift
		{
			Morning,
			Afternoon,
			Night
		}

		public Shift SPShift{ get; set; }

		#region constructors

		//default constructor
		public SupportPerson ()
		{
			SPShift = Shift.Morning;
		}

		//The custom SupportPerson constructor allows to establish a shift and provides defauld benefit package level if
		//it is not specified differently
		public SupportPerson (string fullName, int age, int empID,
		                      float currPay, string ssn, Shift shift)
			: base (fullName, age, empID, currPay, ssn, BenefitPackage.BenefitPackageLevel.Standard)
		{
			// This property is defined by the SupportPerson class.
			SPShift = shift;
		}

		//The custom SupportPerson constructor allows to establish a shift (via a custom enum named SPShift).
		public SupportPerson (string fullName, int age, int empID,
		                      float currPay, string ssn, BenefitPackage.BenefitPackageLevel empbenefit, Shift shift)
			: base (fullName, age, empID, currPay, ssn, empbenefit)
		{
			// This property is defined by the SupportPerson class.
			SPShift = shift;
		}

		#endregion

		/*
		 * A SupportPerson class changes the implementation detail and overrides the virtual method GiveBonus().
		 * This method has been declared virtually in the Employee class.
		*/
		public override void GiveBonus (float amount)
		{
			base.GiveBonus (amount);

		}

		public override float GiveExtra ()
		{
			float extraAmount = base.GiveExtra () + 300;
			//float extraAmount=300;
			return extraAmount;
		}

		public override void GivePromotion (float amount)
		{
			Console.WriteLine ("< SupportPerson >");
			base.GivePromotion (amount);
			Console.WriteLine ();

		}

		public override void GivePromotion ()
		{
			Console.WriteLine ("< SupportPerson >");
			base.GivePromotion ();
			Console.WriteLine ();
		}

		/*
		 * A SupportPerson class changes the implementation detail and overrides the virtual method DisplayStats().
		 * This method has been declared virtually in the Employee class.
		 */

		public override void DisplayStats ()
		{
			base.DisplayStats ();
			Console.WriteLine ("Shift is: {0}", SPShift);
			Console.WriteLine ();
		}

	}

}

