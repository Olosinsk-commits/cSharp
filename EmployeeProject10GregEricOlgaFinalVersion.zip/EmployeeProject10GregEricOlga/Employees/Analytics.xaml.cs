﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Employees
{
    /// <summary>
    /// Interaction logic for Analytics.xaml
    /// </summary>
    public partial class Analytics : Page
    {
        private CompHome compHome;
        private EmployeeList empList;

        public Analytics(CompHome compHome, EmployeeList empList)
        {
            this.compHome = compHome;
            this.empList = empList;

            InitializeComponent();
            ShowChart(empList);
        }

        private void ShowChart(EmployeeList empList)
        {
            //decs
            List<KeyValuePair<string, int>> empByType = new List<KeyValuePair<string, int>>();
            List<KeyValuePair<string, float>> payByType = new List<KeyValuePair<string, float>>();
            List<KeyValuePair<string, double>> expenceByType = new List<KeyValuePair<string, double>>();
            List<KeyValuePair<string, double>> beniftsByType = new List<KeyValuePair<string, double>>();

            //make lists
            empByType = CountEmps(empList);
            expenceByType = CountExpences(empList);
            payByType = CountPay(empList);
            beniftsByType = CountBenifits(empList);

            //bind to charts
            GetEmpByType().DataContext = empByType;
            PayByType.DataContext = payByType;
            ExpenceByType.DataContext = expenceByType;
            BeniftisByType.DataContext = beniftsByType;

        }

        private List<KeyValuePair<string, double>> CountExpences(EmployeeList empList)
        {
            double[] sum = new double[] { 0, 0, 0, 0.001, 0 };

            foreach (Employee e in empList)
            {
                foreach(Expense x in e.Expenses)
                {
                    switch (x.Category)
                    {
                        case ExpenseCategory.Conference:
                            sum[0] += x.Amount;
                            break;
                        case ExpenseCategory.Lodging:
                            sum[1] += x.Amount;
                            break;
                        case ExpenseCategory.Meals:
                            sum[2] += x.Amount;
                            break;
                        case ExpenseCategory.Misc:
                            sum[3] += x.Amount;
                            break;
                        case ExpenseCategory.Travel:
                            sum[4] += x.Amount;
                            break;
                        default:
                            break;
                    }
                }
            }

            //make list
            List<KeyValuePair<string, double>> temp = new List<KeyValuePair<string, double>>();
            temp.Add(new KeyValuePair<string, double>(ExpenseCategory.Conference.ToString(), sum[0]));
            temp.Add(new KeyValuePair<string, double>(ExpenseCategory.Lodging.ToString(), sum[1]));
            temp.Add(new KeyValuePair<string, double>(ExpenseCategory.Meals.ToString(), sum[2]));
            temp.Add(new KeyValuePair<string, double>(ExpenseCategory.Misc.ToString(), sum[3]));
            temp.Add(new KeyValuePair<string, double>(ExpenseCategory.Travel.ToString(), sum[4]));

            return temp;
        }

        private List<KeyValuePair<string, double>> CountBenifits(EmployeeList empList)
        {
            double[] sum = new double[6];

            foreach(Employee e in empList)
            {
                switch (e.GetType().Name)
                {
                    case "Engineer":
                        sum[0] += e.Benefits.ComputePayDeduction();
                        break;
                    case "Executive":
                        sum[1] += e.Benefits.ComputePayDeduction();
                        break;
                    case "Manager":
                        sum[2] += e.Benefits.ComputePayDeduction();
                        break;
                    case "PTSalesEmployee":
                        sum[3] += e.Benefits.ComputePayDeduction();
                        break;
                    case "SalePerson":
                        sum[4] += e.Benefits.ComputePayDeduction();
                        break;
                    case "SupportPerson":
                        sum[5] += e.Benefits.ComputePayDeduction();
                        break;
                    default:
                        break;
                }
            }
            //make list
            List<KeyValuePair<string, double>> temp = new List<KeyValuePair<string, double>>();

            temp.Add(new KeyValuePair<string, double>("Engineer", sum[0]));
            temp.Add(new KeyValuePair<string, double>("Executive", sum[1]));
            temp.Add(new KeyValuePair<string, double>("Manager", sum[2]));
            temp.Add(new KeyValuePair<string, double>("PTSalesEmployee", sum[3]));
            temp.Add(new KeyValuePair<string, double>("SalePerson", sum[4]));
            temp.Add(new KeyValuePair<string, double>("SupportPerson", sum[5]));

            return temp;
        }

        private List<KeyValuePair<string, float>> CountPay(EmployeeList empList)
        {
            float[] sum = new float[6];

            foreach(Employee e in empList)
            {
                switch (e.GetType().Name)
                {
                    case "Engineer":
                        sum[0] += e.Pay;
                        break;
                    case "Executive":
                        sum[1] += e.Pay;
                        break;
                    case "Manager":
                        sum[2] += e.Pay;
                        break;
                    case "PTSalesEmployee":
                        sum[3] += e.Pay;
                        break;
                    case "SalePerson":
                        sum[4] += e.Pay;
                        break;
                    case "SupportPerson":
                        sum[5] += e.Pay;
                        break;
                    default:
                        break;
                }
            }
            //make list
            List<KeyValuePair<string, float>> tmpList = new List<KeyValuePair<string, float>>();
            tmpList.Add(new KeyValuePair<string, float>("Engineer", sum[0]));
            tmpList.Add(new KeyValuePair<string, float>("Execuive", sum[1]));
            tmpList.Add(new KeyValuePair<string, float>("Manager", sum[2]));
            tmpList.Add(new KeyValuePair<string, float>("PTSalsEmployee", sum[3]));
            tmpList.Add(new KeyValuePair<string, float>("SalesPerson", sum[4]));
            tmpList.Add(new KeyValuePair<string, float>("SupportPerson", sum[5]));


            return tmpList;

        }

        private System.Windows.Controls.DataVisualization.Charting.Chart GetEmpByType()
        {
            return EmpByType;
        }

        private List<KeyValuePair<string, int>> CountEmps(EmployeeList empList)
        {
            int[] count = new int[6];

            //count types
             foreach(Employee e in empList)
            {
                switch (e.GetType().Name)
                {
                    case "Engineer":
                        count[0]++;
                        break;
                    case "Executive":
                        count[1]++;
                        break;
                    case "Manager":
                        count[2]++;
                        break;
                    case "PTSalesEmployee":
                        count[3]++;
                        break;
                    case "SalePerson":
                        count[4]++;
                        break;
                    case "SupportPerson":
                        count[5]++;
                        break;
                    default:
                        break;
                }


            }

            //make list
            List<KeyValuePair<string, int>> tmpList = new List<KeyValuePair<string, int>>();
            tmpList.Add(new KeyValuePair<string, int>("Engineer", count[0]));
            tmpList.Add(new KeyValuePair<string, int>("Execuive", count[1]));
            tmpList.Add(new KeyValuePair<string, int>("Manager", count[2]));
            tmpList.Add(new KeyValuePair<string, int>("PTSalsEmployee", count[3]));
            tmpList.Add(new KeyValuePair<string, int>("SalesPerson", count[4]));
            tmpList.Add(new KeyValuePair<string, int>("SupportPerson", count[5]));


            return tmpList;
        }
    }
}
