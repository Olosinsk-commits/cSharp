﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Employees
{

    // Engineers have degrees
    [Serializable]
    public enum DegreeName { BS, MS, PhD }

    public enum ExecTitle { CEO, CTO, CFO, VP }

    public class Employee
    {
        //static int NextId = 1;
        //public int Id { get; }
        //public string FirstName { get; }
        //public string LastName { get; }
        //public DateTime empDOB { get { return empDOB; } }
        //DateTime today = DateTime.Now;
        //public float currPay { get { return currPay; } }
        //public string Name { get { return FirstName + " " + LastName; } }
        //public virtual string Role { get { return GetType().ToString().Substring(10); } }

        // Field data.
        public string Name { get { return FirstName + " " + LastName; } }
        //private string empFirstName;
        //private string empLastName;
        static private int empID = 1;
        private int eID;
        private float currPay;
        private DateTime empDOB;
        private string empSSN;
        DateTime today = DateTime.Now;

        #region Properties 
        public string FirstName { get; }
        public string LastName { get; }
        public int ID { get { return eID; } }
        public float Pay { get { return currPay; } }
        public int Age { get { return today.Year - empDOB.Year; } }
        public DateTime DateOfBirth { get { return empDOB; } }
        public string SocialSecurityNumber { get { return empSSN; } }
        public virtual string Role { get { return GetType().ToString().Substring(10); } }
        #endregion

        public Employee() { }
        public Employee(string firstName, string lastName, DateTime date, float pay, string ssn)
        {
            int id = empID;//provides unique id for each employee
            this.eID = id;
            FirstName = firstName;
            LastName = lastName;
        }

        public virtual void GetSpareProp1(ref string name, ref string value) { }
    }

    public class Executive : Employee
    {
        public ExecTitle Title { get; set; } = ExecTitle.VP;
        public int StockOptions { get; } = 100;

        public Executive() { }
        public Executive(string firstName, string lastName,  DateTime age, float currPay,
                         string ssn, int numbOfOpts = 10000, ExecTitle title= ExecTitle.VP)
             : base(firstName, lastName, age, currPay, ssn)
        {
            Title = title;
            StockOptions = numbOfOpts;
        }

        public override string Role { get { return base.Role + ", " + Title; } }
        public override void GetSpareProp1(ref string name, ref string value)
        {
            name = "Stock Options:";
            value = StockOptions.ToString();
        }
    }

    public class Engineer : Employee
    {
        public DegreeName HighestDegree { get; set; } = DegreeName.BS;

        #region constructors 
        public Engineer() { }

        public Engineer(string firstName, string lastName, DateTime age,
                       float currPay, string ssn, DegreeName degree)
          : base(firstName, lastName, age, currPay, ssn)
        {
            // This property is defined by the Engineer class.
            HighestDegree = degree;
        }
        #endregion
        public override string Role { get { return base.Role; } }
        //public override void GetSpareProp1(ref string name, ref string value)
        //{
        //    name = "Stock Options:";
        //    value = StockOptions.ToString();
        //}


    }


    public class EmployeeList : List<Employee>
    {
        public EmployeeList()
        {            
                Add(new Executive("Dan", "Doe", DateTime.Parse("3/20/1963"), 200000, "121-12-1211", 50000, ExecTitle.CEO));
        }
    }

    public partial class CompHome : Page
    {
        static EmployeeList empList = new EmployeeList();

        public CompHome()
        {
            InitializeComponent();

            // Select the All radio button
            this.employeeTypeRadioButtons.SelectedIndex = 0;

            // Set event handler for radio button changes
            this.employeeTypeRadioButtons.SelectionChanged += new SelectionChangedEventHandler(employeeTypeRadioButtons_SelectionChanged);

            // Fill the Employees data grid
            dgEmps.ItemsSource = empList;
        }

        private void Details_Click(object sender, RoutedEventArgs e)
        {
            // Show Employee details if one selected
            if (dgEmps.SelectedIndex >= 0)
            {
                this.NavigationService.Navigate(new CompDetails(this.dgEmps.SelectedItem));
            }
        }

        // Handle changes to Employee type radio buttons
        void employeeTypeRadioButtons_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Only choices are All (0) or Executives (1)
            if (this.employeeTypeRadioButtons.SelectedIndex == 1)
              dgEmps.ItemsSource = (List<Employee>)empList.FindAll(obj => obj is Executive); 
            else dgEmps.ItemsSource = empList;
        }
    }
}
