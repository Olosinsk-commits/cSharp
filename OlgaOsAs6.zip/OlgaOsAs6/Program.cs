﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Employees
{
	class Program
	{
		static void Main ()
		{
			Console.WriteLine ("Olga Osinskaya");
			Console.WriteLine ("11/4/2017\n");

			Console.WriteLine ("***** Assignment 6: Employee Reports.*****\n" +
			"Delegates, Events, and Lambda Expressions.");

			// Create Employees
			Manager chucky = new Manager ("Chucky", 50, 92, 100000, "333-23-2322", 9000);
			Manager mary = new Manager ("Mary", 54, 90, 200000, "121-12-1211", 9500);
			SalesPerson fran = new SalesPerson ("Fran", 43, 93, 80000, "932-32-3232", 31);
			SalesPerson bob = new SalesPerson ("Bob", 31, 94, 120000, "334-24-2422", 30);
			PTSalesPerson sally = new PTSalesPerson ("Sally", 32, 95, 30000, "913-43-4343", 10);
			PTSalesPerson sam = new PTSalesPerson ("Sam", 33, 96, 20000, "525-76-5030", 20);
			PTSalesPerson mike = new PTSalesPerson ("Mike", 45, 91, 15000, "229-67-7898", 30);

			// Employee list
			Employee[] emps = { chucky, mary, fran, bob, sally, sam, mike };

			Console.WriteLine ("******************************************\n");

			//-----------------------traditional delegate syntax ----------------------------
			// register event handler in the traditional delegate syntax
			#region target for event handlers
			EventHandler<ManagerEventArgs> d = new EventHandler<ManagerEventArgs> (ManagerListIsFull);

			foreach (Employee emp in emps) {				

				if (emp is Manager) {
					
					Manager man = (Manager)emp;
					man.OnTooManyReports += d;

				}
			}
				
			//-----------------------anonymous method----------------------------
			//register event handler using anonymous method
			foreach (Employee empA in emps) {	
				if (empA is Manager) {
					
					Manager man = (Manager)empA;

					man.OnTooManyReports += (sender, e) => {
						Console.WriteLine ("Anonymous methods:           " + e.DisplayMessage ());
					};
				}
			}


			//-----------------------lambda expression----------------------------
			//register event handler using lambda expression
			foreach (Employee empL in emps) {	
				if (empL is Manager) {
					Manager man = (Manager)empL;
					man.OnTooManyReports += (sender, e) => { 
						Console.WriteLine ("Lambda expression:           " + e.DisplayMessage ());
					};
				}
			}
			#endregion

			mary.AddReport (mike);
			chucky.AddReport (bob);
			chucky.AddReport (sally);
			chucky.AddReport (sam);
			mary.RemoveReport (fran);
			mary.RemoveReport (chucky);
			chucky.AddReport (fran);
			chucky.AddReport (mike);
			chucky.AddReport (mary);

			Console.WriteLine ("\nDisplay Managers\n");
			mary.DisplayStats ();
			Console.WriteLine ();
			chucky.RemoveReport (sam); // Remove a report for testing
			chucky.DisplayStats ();
			Console.Write ("Reports by Name: ");
			foreach (Employee emp in chucky.ReportsByName())
				Console.Write ("{0} ", emp.Name);
			Console.Write ("\nReports by Age: ");

			foreach (Employee emp in chucky.ReportsByAge())
				Console.Write ("{0}-{1} ", emp.Age, emp.Name);
			Console.Write ("\nReports by Pay: ");
			foreach (Employee emp in chucky.ReportsByPay())
				Console.Write ("{0:C}-{1} ", emp.Pay, emp.Name);
			Console.WriteLine ();
			Console.ReadLine ();


		}
		#region Targets for events
		private static void ManagerListIsFull (object sender, ManagerEventArgs e)
		{
			// Just to be safe, perform a
			// runtime check before casting.
			if (sender is Employee) {
				Employee c = (Employee)sender;
				Console.WriteLine ("Traditional delegate syntax: " + e.DisplayMessage ());

			} else
				throw new ArgumentException ("Parameter is not an Employee!");
		}
		#endregion
	}
}