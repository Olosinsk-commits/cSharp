﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Employees
{
	// Managers need to know their number of stock options and reports
	public class Manager : Employee, IEnumerable<Employee> , IEnumerable
	{
		#region constructors

		public Manager ()
		{
		}

		public Manager (string fullName, int age, int empID,
		                float currPay, string ssn, int numbOfOpts)
			: base (fullName, age, empID, currPay, ssn)
		{
			// This property is defined by the Manager class.
			StockOptions = numbOfOpts;
		}

		#endregion

		#region Constants, data members and properties

		// Add a private member for reports
		public const int MaxReports = 5;
		private List<Employee> _reports = new List<Employee> (5);

		// Stock options unique to Managers
		public int StockOptions { get; set; }

		#endregion

		#region Class Methods

		// Enumerate reports for Manager

		IEnumerator IEnumerable.GetEnumerator ()
		{
			return this._reports.GetEnumerator ();
		}
		//implement interface member 'IEnumerable<Employee>.GetEnumerator()'

		public IEnumerator<Employee> GetEnumerator ()
		{
			return _reports.GetEnumerator ();
		}

		// Enumerate reports, sorted by Employee Name, Age, and Pay
		public IEnumerable<Employee> ReportsByName ()
		{
			return GetReports (Employee.SortByName);
		}
		// return ((IComparer<Employee>)new SortByNameClass())
		public IEnumerable<Employee>   ReportsByAge ()
		{
			return GetReports (Employee.SortByAge);
		}

		public IEnumerable<Employee>   ReportsByPay ()
		{
			return GetReports (Employee.SortByPay);
		}

		// Enumerator to return reports in passed sort order
		private IEnumerable<Employee> GetReports (IComparer<Employee>  sortOrder)
		{
			_reports.Sort (sortOrder);
			return _reports;

		}
		// Override GiveBonus to change stock options for Manager
		public override void GiveBonus (float amount)
		{
			base.GiveBonus (amount);
			Random r = new Random ();
			StockOptions += r.Next (500);
		}
			
		// This manager can send this event.
		public event EventHandler<ManagerEventArgs> OnTooManyReports;


		// Methods for adding/removing reports
		public virtual void AddReport (Employee report)
		{
			if (_reports.Count >= MaxReports && OnTooManyReports != null) {
				// If the report list is full, fire EventHandler event.
				OnTooManyReports (this, new ManagerEventArgs (this, report));

			}

            // Only add report if not already a report and not same as this
			else if (_reports.Count <= MaxReports && this != report) {
				// Put Employee in empty position
				_reports.Add (report);
			}
		}

		public virtual void RemoveReport (Employee report)
		{
			if (_reports.Count == 0) {
				Console.WriteLine ("Error! Employee list is empty!");
				Console.WriteLine ();
			}

			foreach (Employee empl in _reports) {
				//ArrayList.Contains() method checks whether specified element exists in the ArrayList or not. Returns true if exists otherwise false.
				if (_reports.Contains (empl) == false) {
					Console.WriteLine ("Error! This employee is not present in the {0}'s report list!", Name);
					Console.WriteLine ();
				} 	

			}
			_reports.Remove (report);
		}
		// Display Manager with stock options and list of reports
		public override void DisplayStats ()
		{
			base.DisplayStats ();
			Console.WriteLine ("Stock Options: {0:N0}", StockOptions);

			// Print out reports on a single line
			Console.Write ("Reports: ");
			foreach (Employee emp in this)
				Console.Write ("{0} ", emp.Name);
			Console.WriteLine ();
		}

		#endregion
	}
}