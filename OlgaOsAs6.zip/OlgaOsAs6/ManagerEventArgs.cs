﻿using System;

namespace Employees
{
	//The ManagerEventArgs class defines two data members to hold references to the Manager and Employee passed
	//to the AddReport method call.

	public class ManagerEventArgs: EventArgs
	{
		public readonly Manager manager;
		public readonly Employee employee;

		public ManagerEventArgs ()
		{
		}

		public ManagerEventArgs (Manager managerM, Employee employeeE)
		{
			manager = managerM;
			employee = employeeE;
		}
		//The virtual method DisplayMessage returns the message string
		public virtual string DisplayMessage ()
		{
			return string.Format ("{0} has {1} reports. Can not add report: {2}.", manager.Name, Manager.MaxReports, employee.Name);
		}

	}
}

