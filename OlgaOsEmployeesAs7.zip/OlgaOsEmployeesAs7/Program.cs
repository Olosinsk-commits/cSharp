﻿using System;
using System.Collections.Generic;

// Gain access to the BinaryFormatter in mscorlib.dll.
using System.Runtime.Serialization.Formatters.Binary;

// Must reference System.Runtime.Serialization.Formatters.Soap.dll.
//using System.Runtime.Serialization.Formatters.Soap;

// Defined within System.Xml.dll.
using System.Xml.Serialization;
using System.IO;

namespace Employees
{
    class Program
    {
        static void Main()
        {
			Console.WriteLine("======================================");
			Console.WriteLine("Olga Osinskaya");

			Console.WriteLine("Assignment 7: Employee Serialization");
			Console.WriteLine("======================================\n");

            List<Employee> emps = InitialEmployees();

            Console.WriteLine("Employees after Initialization:\n");
            DisplayEmployees(emps);

            Console.WriteLine("Employees after Binary save/load:\n");

			//SaveAsBinaryFormat binary serializes emps to a file
			SaveAsBinaryFormat(emps, "EmpFile.dat");


			// LoadFromBinaryFile loads list of employees from binary file
			 emps=LoadFromBinaryFile ("EmpFile.dat");

            DisplayEmployees(emps);

            Console.ReadLine();

        }

        // Display the passed employee list
        static void DisplayEmployees(List<Employee> emps)
        {
            foreach (Employee emp in emps)
            {
                emp.DisplayStats();
                Console.WriteLine();
            }
        }

		#region Save as binary
		static void SaveAsBinaryFormat(object objGraph, string fileName)
		{
			// Save object to a file named CarData.dat in binary.
			BinaryFormatter binFormat = new BinaryFormatter();

			using (Stream fStream = new FileStream(fileName,
				FileMode.Create, FileAccess.Write, FileShare.None))
			{
				binFormat.Serialize(fStream, objGraph);
			}
		} 
		#endregion

		#region Load from binary
		static List<Employee> LoadFromBinaryFile(string fileName)
		{
			BinaryFormatter binFormat = new BinaryFormatter();

			// Read the data from the binary file.
			using (Stream fStream = File.OpenRead(fileName))
			{
				
				return (List<Employee>)binFormat.Deserialize(fStream);
			}
		} 
		#endregion

        static List<Employee> InitialEmployees()
        {
            // Create Employees - old constructor calls
//            Executive dan = new Executive("Dan", 54, 1, 200000, "121-12-1211", 50000, ExecTitle.CEO);
//            Executive connie = new Executive("Connie", 45, 2, 150000, "229-67-7898", 40000, ExecTitle.CFO);
//            Manager chucky = new Manager("Chucky", 50, 3, 100000, "333-23-2322", 9000);
//            Manager mary = new Manager("Mary", 54, 4, 200000, "121-12-1211", 9500);
//            Engineer bob = new Engineer("Bob", 31, 5, 120000, "334-24-2422", DegreeName.MS);
//            SalesPerson fran = new SalesPerson("Fran", 43, 6, 80000, "932-32-3232", 31);
//            PTSalesPerson sam = new PTSalesPerson("Sam", 33, 7, 20000, "525-76-5030", 20);
//            PTSalesPerson sally = new PTSalesPerson("Sally", 8, 96, 30000, "913-43-4343", 10);
//            SupportPerson mike = new SupportPerson("Mike", 45, 9, 15000, "229-67-7898", ShiftName.One);
//            SupportPerson steve = new SupportPerson("Steve", 32, 10, 80000, "913-43-4343", ShiftName.Two);
//
            // Create Employees - new constructor calls (with Age/ID changes)
            Executive dan = new Executive("Dan", DateTime.Parse("3/20/1963"), 200000, "121-12-1211", 50000, ExecTitle.CEO);
            Executive connie = new Executive("Connie", DateTime.Parse("2/5/1972"), 150000, "229-67-7898", 40000, ExecTitle.CFO);
            Manager chucky = new Manager("Chucky", DateTime.Parse("4/23/1967"), 100000, "333-23-2322", 9000);
            Manager mary = new Manager("Mary", DateTime.Parse("5/9/1963"), 200000,  "121-12-1211", 9500);
            Engineer bob = new Engineer("Bob", DateTime.Parse("6/30/1986"), 120000,  "334-24-2422", DegreeName.MS);
            SalesPerson fran = new SalesPerson("Fran", DateTime.Parse("7/5/1975"), 80000, "932-32-3232", 31);
            PTSalesPerson sam = new PTSalesPerson("Sam", DateTime.Parse("8/11/1984"), 20000, "525-76-5030", 20);
            PTSalesPerson sally = new PTSalesPerson("Sally", DateTime.Parse("9/12/1979"), 30000, "913-43-4343", 10);
            SupportPerson mike = new SupportPerson("Mike", DateTime.Parse("10/31/1975"), 15000, "229-67-7898", ShiftName.One);
            SupportPerson steve = new SupportPerson("Steve", DateTime.Parse("11/21/1982"),  80000, "913-43-4343", ShiftName.Two);


            // Bonuses and promotions
            dan.GiveBonus(1000);
            bob.GiveBonus(500);
            sally.GiveBonus(400);
            dan.GivePromotion();
            chucky.GivePromotion();
            fran.GivePromotion();


            // Add reports - just report error and continue on exception
            try
            {
                dan.AddReport(chucky);
                dan.AddReport(mary);
                connie.AddReport(fran);
                connie.AddReport(sally);
                mary.AddReport(sam);
                mary.AddReport(mike);
                chucky.AddReport(bob);
                chucky.AddReport(steve);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error when adding reports: {e.Message}");
            }

			Console.Write ("\nReports by Age: ");

            return new List<Employee>() { dan, connie, chucky, mary, bob, fran, 
                                          sam, sally, mike, steve };
        }
    }
}