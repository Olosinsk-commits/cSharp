﻿using System;

namespace Employees
{
	[Serializable]
    public partial class Employee
    {

        // Field data.
        private string empName;
        static private int empID=1;
		private int eID;
        private float currPay;
        //private int empAge;

		//empDOB (Date of Birth) field helds the DateTime of the Employee's birth. 
		private DateTime empDOB;
        private string empSSN;
		DateTime today = DateTime.Now;


        #region Constructors
        public Employee() { }

		public Employee(string name, DateTime date, float pay, string ssn)
        {
            empName = name;
			empDOB = date;
            currPay = pay;
            empSSN = ssn;
			int id = empID;//provides unique id for each employee
			this.eID = id;
			empID++;
        }

        #endregion

        #region Properties 
        public string Name { get { return empName; } }
		public int ID { get { return eID; } }
        public float Pay { get { return currPay; } }
		public int Age { get { return today.Year-empDOB.Year; } }
		public DateTime DateOfBirth { get { return empDOB; } }
        public string SocialSecurityNumber { get { return empSSN; } }
        #endregion
    }
}