﻿using System;
using System.Runtime.Serialization.Formatters.Binary;

// Must reference System.Runtime.Serialization.Formatters.Soap.dll.
//using System.Runtime.Serialization.Formatters.Soap;

// Defined within System.Xml.dll.
using System.Xml.Serialization;
using System.IO;

namespace Employees
{
	// Engineers have degrees
	[Serializable]
    public enum DegreeName { BS, MS, PhD }

	[Serializable]
    public class Engineer : Employee
    {
        public DegreeName HighestDegree { get; set; } = DegreeName.BS;

        #region constructors 
		public Engineer() { }

		public Engineer(string fullName, DateTime age, 
					   float currPay, string ssn, DegreeName degree)
          : base(fullName, age,  currPay, ssn)
        {
            // This property is defined by the Engineer class.
            HighestDegree = degree;
		}
		#endregion

		public override void DisplayStats()
		{
			base.DisplayStats();
			Console.WriteLine("Highest Degree: {0}", HighestDegree);
		}
    }
}
