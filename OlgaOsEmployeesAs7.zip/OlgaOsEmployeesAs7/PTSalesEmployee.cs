﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;

// Must reference System.Runtime.Serialization.Formatters.Soap.dll.
//using System.Runtime.Serialization.Formatters.Soap;

// Defined within System.Xml.dll.
using System.Xml.Serialization;
using System.IO;


namespace Employees
{

	[Serializable]
    sealed class PTSalesPerson : SalesPerson
    {
		public PTSalesPerson(string fullName, DateTime age, 
                             float currPay, string ssn, int numbOfSales)
          : base(fullName, age,  currPay, ssn, numbOfSales)
        {
        }
        // Assume other members here...
    }
}
