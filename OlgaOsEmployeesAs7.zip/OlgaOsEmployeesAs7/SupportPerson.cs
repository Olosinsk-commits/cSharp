﻿using System;
using System.Runtime.Serialization.Formatters.Binary;

// Must reference System.Runtime.Serialization.Formatters.Soap.dll.
//using System.Runtime.Serialization.Formatters.Soap;

// Defined within System.Xml.dll.
using System.Xml.Serialization;
using System.IO;


namespace Employees
{
	// SupportPerson works a shift
	[Serializable]
    public enum ShiftName { One, Two, Three }
	[Serializable]
    public class SupportPerson : Employee
    {
        public ShiftName Shift { get; set; } = ShiftName.One;

		#region constructors 
		public SupportPerson() { }

		public SupportPerson(string fullName, DateTime age, 
                             float currPay, string ssn, ShiftName shift)
          : base(fullName, age,  currPay, ssn)
        {
            // This property is defined by the SupportPerson class.
            Shift = shift;
		}
		#endregion

		public override void DisplayStats()
		{
			base.DisplayStats();
			Console.WriteLine("Shift: {0}", Shift);
		}
    }
}
